package edu.ucsb.ece150.gauchopay;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.braintreepayments.cardform.view.CardForm;

import java.util.ArrayList;

public class AddCardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_card);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Add Card");
        setSupportActionBar(toolbar);

        // Note that the requirements here are just for creating the fields on the form. For
        // example, if the cvvRequired setting was set to "false", the form would not contain
        // a field for CVV. ("Requirement" DOES NOT mean "Valid".)
        final CardForm cardForm = findViewById(R.id.card_form);
        cardForm.cardRequired(true)
                .expirationRequired(true)
                .cvvRequired(true)
                .postalCodeRequired(true)
                .actionLabel("Add Card")
                .setup(this);
        Toast.makeText(this, "Cardform made", Toast.LENGTH_SHORT).show();

        Button save;
        save = findViewById(R.id.btnSave);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetchCardInfo();
            }
        });
    }
    @Override
    protected void onPause() {
        super.onPause();
        // SharedPreferences loginData = getSharedPreferences(SAVED_TEXT, Context.MODE_PRIVATE);
        // SharedPreferences.Editor editor = loginData.edit();
        // editor.putString("userName", userName.getText().toString());
        Toast.makeText(this,"Paused",Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // SharedPreferences loginData = getSharedPreferences(SAVED_TEXT, Context.MODE_PRIVATE);
        // String name = loginData.getString("userName", "");
        Toast.makeText(this,"Resumed",Toast.LENGTH_SHORT).show();

    }
    protected void fetchCardInfo(){
        // [DONE] Implement a method of getting card information and sending it to the main activity.
        // You will want to add a new component onto this activity's layout so you can perform this
        // task as a result of a button click.
        // https://github.com/braintree/android-card-form/blob/master/README.md.

        CardForm cardForm = (CardForm) findViewById(R.id.card_form);
        if (cardForm != null) {
            if (cardForm.isValid()) {
                // Arraylists are nifty and easy.
                ArrayList<String> unencryptedData = new ArrayList<String>();
                // Use cardForm builtin methods to fetch data we want to strings
                String CardNumber = cardForm.getCardNumber();
                String ExpirationMonth = cardForm.getExpirationMonth();
                String ExpirationYear = cardForm.getExpirationYear();
                String Cvv = cardForm.getCvv();
                String PostalCode = cardForm.getPostalCode();

                // Make sure user is happy with what she typed
                AlertDialog.Builder alertBuilder = new AlertDialog.Builder(AddCardActivity.this);
                alertBuilder.setTitle("Confirm before saving");
                alertBuilder.setMessage("Card number: " + CardNumber + "\n" +
                        "Card expiry date: " + ExpirationMonth + "/" + ExpirationYear + "\n" +
                        "Card CVV: " + Cvv + "\n" +
                        "Postal code: " + PostalCode + "\n");
                alertBuilder.setPositiveButton("Accept", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        // This information has to be sent back to the CardListActivity (to update the
                        // list of cards).
                        unencryptedData.add(CardNumber);
                        unencryptedData.add(ExpirationMonth);
                        unencryptedData.add(ExpirationYear);
                        unencryptedData.add(Cvv);
                        unencryptedData.add(PostalCode);
                        dialogInterface.dismiss();
                        Intent toCardListActivity = new Intent(getApplicationContext(), CardListActivity.class);

                        // Failing miserably unless I convert to string
                        toCardListActivity.putExtra("encryptedData", unencryptedData.toString());
                        toCardListActivity.putExtra("cardNumber", CardNumber);
                        startActivity(toCardListActivity);
                        finish();
                        Toast.makeText(AddCardActivity.this, "Card confirmed", Toast.LENGTH_SHORT).show();
                    }
                });
                alertBuilder.setNegativeButton("Deny", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                AlertDialog alertDialog = alertBuilder.create();
                alertDialog.show();
            } else
                Toast.makeText(this, "Could not read card.", Toast.LENGTH_LONG).show();
        }
    }
}