package edu.ucsb.ece150.gauchopay;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

//notification wrangling

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.core.app.NotificationCompat;  // Import from AndroidX instead of support (got updated)
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import android.view.GestureDetector;
import android.view.MotionEvent;


public class CardListActivity extends AppCompatActivity {
    private static final String SAVED_TEXT = "userCards";
    private static final int RC_HANDLE_INTERNET_PERMISSION = 2;

    private ArrayList<String> cardArray;
    private ArrayAdapter adapter;

    private ListView cardList;
    private Handler handler = new Handler();
    private Timer timer = new Timer();
    TimerTask task = new TimerTask() {
        @Override
        public void run() {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    // Launch the asynchronous process to grab the web API
                    new ReadWebServer(getApplicationContext()).execute("");
                }
            });
        }
    };

    //separate timer to check if we are getting paid

    TimerTask task2 = new TimerTask() {
        @Override
        public void run() {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    //Get the notification, thanks for the timer boilerplate :)
                    if (ReadWebServer.getLastAmount() != 0) {
                        Toast.makeText(getApplicationContext(), ReadWebServer.getLastAmount() + " Requested", Toast.LENGTH_LONG).show();
                    }
                    }
            });
        }
    };


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_list);


        // Ensure that we have Internet permissions
        int internetPermissionGranted = ActivityCompat.checkSelfPermission(this, Manifest.permission.INTERNET);
        if(internetPermissionGranted != PackageManager.PERMISSION_GRANTED) {
            final String[] permission = new String[] {Manifest.permission.INTERNET};
            ActivityCompat.requestPermissions(this, permission, RC_HANDLE_INTERNET_PERMISSION);
        }


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        cardArray = new ArrayList<>();
        cardList = findViewById(R.id.cardList);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, cardArray);
        cardList.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent toAddCardActivity = new Intent(getApplicationContext(), AddCardActivity.class);
                startActivity(toAddCardActivity);
            }
        });


        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        //When you target Android 8.0 (API level 26), you must implement notification channels to display notifications
        String NOTIFICATION_CHANNEL_ID = "my_channel_id_01";

        // Create a notification channel if API level is 26 or higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "my_channel";
            String description = "ECE 150 - UCSB Channel";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            // Create a new Notification Channel
            NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            notificationManager.createNotificationChannel(channel);
        }


        GestureDetector gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            public void onLongPress(MotionEvent e, int position) {
                super.onLongPress(e);
                Toast.makeText(CardListActivity.this, "Deleting card", Toast.LENGTH_SHORT).show();
                cardArray.remove(position);
            }
        });

        cardList.setOnTouchListener(new AdapterView.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return gestureDetector.onTouchEvent(event);
            }
        });




        cardList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final int posID = (int) id;

                // If "lastAmount > 0" the last API call is a valid request (that the user must
                // respond to.
                if (ReadWebServer.getLastAmount() != 0) {
                    // [DONE] Send the card information back to the web API. Reference the
                    // WriteWebServer constructor to know what information must be passed.
                    // Get the card number from the cardArray based on the position in the array.
                    String hoping = cardArray.get(position);
                    new WriteWebServer(getApplicationContext(), hoping).execute();
                    Toast.makeText(getApplicationContext(), ReadWebServer.getLastAmount() + " Sent!", Toast.LENGTH_LONG).show();
                    // Reset the stored information from the last API call
                    ReadWebServer.resetLastAmount();
                }
            }
        });

        // Start the timer to poll the webserver every 5000 ms
        timer.schedule(task, 0, 5000);
        timer.schedule(task2, 0, 5000);


        SharedPreferences loginData = getSharedPreferences(SAVED_TEXT, Context.MODE_PRIVATE);
        String name = loginData.getString("userCards", "");
        cardArray.add(name);

    }

    @Override
    protected void onResume() {
        super.onResume();

        // [DONE] This is a placeholder. Modify the card information in the cardArray ArrayList
        // accordingly.
        cardArray.clear();
        String encryptedData = getIntent().getStringExtra("encryptedData");
        String cardNumber = getIntent().getStringExtra("cardNumber");
        if (cardNumber != null) {
            cardArray.add(cardNumber); }
        else {
            Toast.makeText(this, "Welcome cat.", Toast.LENGTH_LONG).show();
        }

        SharedPreferences loginData = getSharedPreferences(SAVED_TEXT, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = loginData.edit();
        editor.putString("userCards", cardNumber);
        editor.apply();

        adapter.notifyDataSetChanged();
    }
}
