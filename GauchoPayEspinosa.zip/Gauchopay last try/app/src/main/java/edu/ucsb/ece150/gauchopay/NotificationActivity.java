package edu.ucsb.ece150.gauchopay;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

//notification wrangling

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.core.app.NotificationCompat;  // Import from AndroidX instead of support (got updated)
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;


public class NotificationActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_list);
    }

    public void onUse(View view) {
        // A notification is added to the bar through the NotificationManager
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        //When you target Android 8.0 (API level 26), you must implement notification channels to display notifications
        String NOTIFICATION_CHANNEL_ID = "my_channel_id_01";

        // Create a notification channel if API level is 26 or higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "my_channel";
            String description = "ECE 150 - UCSB Channel";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            // Create a new Notification Channel
            NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            notificationManager.createNotificationChannel(channel);
        }

        // We need to set the notification's content and channel using a NotificationCompat.Builder object
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID);
        notificationBuilder.setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_ALL)
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("ECE 150 - UCSB")
                .setContentText("My first random notification")
                .setContentInfo("Info");

        // Call the notify() method to show the notification
        notificationManager.notify(/*notification id*/1, notificationBuilder.build());


    }
}